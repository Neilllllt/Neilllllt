import torch
import PIL
from PIL import Image
from smolagents.models import Model, ChatMessage


class QwenVLModel(Model):
    """
    Custom SmolAgents model wrapper for Qwen2.5-VL that supports
    image passing.
    """

    def __init__(
        self,
        model_id: str = "Qwen/Qwen3-VL-8B-Instruct",
        load_in_4bit: bool = False,
        load_in_8bit: bool = False,
        max_new_tokens: int = 1500,
        **kwargs,
    ):
        # Initialize parent Model class
        super().__init__(flatten_messages_as_text=False, **kwargs)

        self.model_id = model_id
        self.max_new_tokens = max_new_tokens

        # Import here for temporary
        from transformers import (
            Qwen3VLForConditionalGeneration,
            AutoProcessor,
            BitsAndBytesConfig,
        )

        # Build quantization config
        quant_config = None
        if load_in_4bit:
            quant_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16,
            )
        elif load_in_8bit:
            quant_config = BitsAndBytesConfig(load_in_8bit=True)

        # Load model and processor
        model_kwargs = {
            "device_map": "auto",
            "trust_remote_code": True,
        }
        if quant_config:
            model_kwargs["quantization_config"] = quant_config

        print(f"Loading {model_id}...")
        self.model = Qwen3VLForConditionalGeneration.from_pretrained(
            model_id, **model_kwargs
        )
        self.processor = AutoProcessor.from_pretrained(
            model_id, trust_remote_code=True
        )
        print("Model loaded.")

    def generate(
        self,
        messages,
        stop_sequences=None,
        **kwargs,
    ):
        """
        Generate a response from the VLM. Returns a ChatMessage.
        """
        qwen_messages = []
        all_images = []

        for msg in messages:
            role = msg.get("role", "user") if isinstance(msg, dict) else getattr(msg, "role", "user")
            content = msg.get("content", "") if isinstance(msg, dict) else getattr(msg, "content", "")

            if isinstance(content, str):
                # Pure text message
                qwen_messages.append({
                    "role": role,
                    "content": [{"type": "text", "text": content}],
                })

            elif isinstance(content, list):
                # Mixed content (text + images)
                qwen_content = []
                for item in content:
                    if isinstance(item, dict):
                        if item.get("type") == "text":
                            qwen_content.append({
                                "type": "text",
                                "text": item.get("text", ""),
                            })
                        elif item.get("type") == "image":
                            # SmolAgents puts PIL images in item["image"]
                            img = item.get("image")
                            if isinstance(img, Image.Image):
                                img = img.convert("RGB")
                                all_images.append(img)
                                qwen_content.append({
                                    "type": "image",
                                    "image": img,
                                })
                            elif isinstance(img, str):
                                # It's a file path or base64 try to open it
                                try:
                                    pil_img = Image.open(img).convert("RGB")
                                    all_images.append(pil_img)
                                    qwen_content.append({
                                        "type": "image",
                                        "image": pil_img,
                                    })
                                except Exception:
                                    qwen_content.append({
                                        "type": "text",
                                        "text": f"[Image at: {img}]",
                                    })
                    elif isinstance(item, str):
                        qwen_content.append({"type": "text", "text": item})

                if qwen_content:
                    qwen_messages.append({
                        "role": role,
                        "content": qwen_content,
                    })
            else:
                # Fallback
                qwen_messages.append({
                    "role": role,
                    "content": [{"type": "text", "text": str(content)}],
                })

        # Process with Qwen's processor
        text = self.processor.apply_chat_template(
            qwen_messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )

        inputs = self.processor(
            text=[text],
            images=all_images if all_images else None,
            return_tensors="pt",
            padding=True,
        ).to(self.model.device)

        # Generate
        output_ids = self.model.generate(
            **inputs,
            max_new_tokens=self.max_new_tokens,
        )

        # Trim the input tokens from the output
        generated_ids = output_ids[0][inputs["input_ids"].shape[1]:]
        response_text = self.processor.decode(
            generated_ids, skip_special_tokens=True
        )

        # Handle stop sequences
        if stop_sequences:
            for stop_seq in stop_sequences:
                if stop_seq in response_text:
                    response_text = response_text[:response_text.index(stop_seq)]

        # Return in SmolAgents format
        return ChatMessage(role="assistant", content=response_text)