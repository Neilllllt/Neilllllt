"""
Quick smoke test for the chest X-ray segmentation tool.

Usage:
    python test_segmentation.py                          # uses a sample from torchxrayvision
    python test_segmentation.py path/to/chest_xray.png   # uses your own image
"""

import sys
import os
import numpy as np
from PIL import Image


def create_sample_xray(save_path: str) -> str:
    """Download a sample chest X-ray from torchxrayvision's built-in data."""
    try:
        import torchxrayvision as xrv
        # Use one of xrv's bundled sample images
        img = xrv.utils.load_image("https://raw.githubusercontent.com/mlmed/torchxrayvision/master/tests/16747_3_1.jpg")
        # img shape: (1, H, W), range [-1024, 1024]
        # Convert back to [0, 255] for saving as PNG
        img_np = ((img[0] + 1024) / 2048 * 255).clip(0, 255).astype(np.uint8)
        Image.fromarray(img_np, mode="L").save(save_path)
        print(f"[OK] Sample X-ray saved to: {save_path}")
        return save_path
    except Exception as e:
        print(f"[WARN] Could not download sample image: {e}")
        # Fallback: create a dummy grayscale image
        dummy = np.random.randint(0, 255, (512, 512), dtype=np.uint8)
        Image.fromarray(dummy, mode="L").save(save_path)
        print(f"[OK] Created dummy test image: {save_path}")
        return save_path


def main():
    # ── 1. Get or create a test image ────────────────────────────────────
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        assert os.path.exists(image_path), f"File not found: {image_path}"
        print(f"Using provided image: {image_path}")
    else:
        image_path = "test_chest_xray.png"
        print("No image provided, downloading a sample...")
        create_sample_xray(image_path)

    # ── 2. Run the segmentation tool ─────────────────────────────────────
    print("\n--- Running segment_chest_xray() ---")
    from tools import segment_chest_xray

    result = segment_chest_xray(image_path)
    print(f"\nTool returned:\n{result}")

    # ── 3. Verify the output ─────────────────────────────────────────────
    # The result string should contain a path ending in _segmented.png
    if "segmented.png" in result:
        # Extract path from the summary text
        for token in result.split():
            if token.endswith("segmented.png"):
                out_path = token
                break
        else:
            out_path = None

        if out_path and os.path.exists(out_path):
            img = Image.open(out_path)
            print(f"\n[PASS] Output image exists: {out_path}")
            print(f"       Size: {img.size}, Mode: {img.mode}")
        else:
            print(f"\n[FAIL] Output path not found on disk")
    else:
        print("\n[FAIL] Tool did not return expected output format")


if __name__ == "__main__":
    main()