import os
import sys
import glob
import yaml
import tempfile
import PIL
from PIL import Image
import gradio as gr
import torch
from transformers import BitsAndBytesConfig
from smolagents import CodeAgent, TransformersModel


# Local
from tools import segment_brain_mri_abnormality, segment_chest_xray, detect_chest_xray_lesion
from vlm_model import QwenVLModel


# =============================================================
with open('prompt.yml', 'r') as file:
    PROMPT = yaml.safe_load(file)

# Detect device
if torch.cuda.is_available():
    device = 'cuda'
    print(f'Using CUDA: {torch.cuda.get_device_name(0)}')
elif torch.backends.mps.is_available():
    device = 'mps'
    print('Using Apple MPS')
else:
    device = 'cpu'
    print('WARNING: No GPU detected, using CPU')

# VLM models
MODEL_ID = 'Qwen/Qwen3-VL-8B-Instruct'
# MODEL_ID = 'lingshu-medical-mllm/Lingshu-7B'
# MODEL_ID = 'lingshu-medical-mllm/Lingshu-32B'

model = QwenVLModel(
    model_id=MODEL_ID,
    load_in_4bit=True,
)

agent = CodeAgent(
    tools=[segment_chest_xray, segment_brain_mri_abnormality, detect_chest_xray_lesion],
    model=model,
    additional_authorized_imports=['os', 'ntpath', 'pathlib', 'PIL', 'PIL.Image'],
    verbosity_level=2, # 1: Normal, 2: Debug
    max_steps=6
)


# =============================================================
# AGENT INTERFACE

def find_latest_segmented_image():
    """Check temp directory for the most recent segmentation output."""
    tmp = tempfile.gettempdir()
    candidates = glob.glob(os.path.join(tmp, "*_segmented.png"))
    if candidates:
        return max(candidates, key=os.path.getmtime)
    return None

_last_seg_path = None   # Last segmented image
_last_image_path = None # Last uploaded image

def run_agent(image, message, chat_history):
    global _last_seg_path, _last_image_path

    if image is None and not message:
        return chat_history, None, ""

    chat_history = chat_history or []
    user_msg = message if message else "(uploaded image for analysis)"

    # Save uploaded image to disk if provided
    image_path = None
    if image is not None:
        image_path = os.path.join(tempfile.gettempdir(), "uploaded_medical_image.png")
        image.save(image_path)
        _last_image_path = image_path

    try:
        # ── FOLLOW-UP: segmentation already done, single-step Q&A ────
        if _last_seg_path is not None and message:
            # Re-provide original + segmentation so the VLM can still see them
            context_images = []
            if _last_image_path and os.path.isfile(_last_image_path):
                context_images.append(Image.open(_last_image_path))
            if os.path.isfile(_last_seg_path):
                context_images.append(Image.open(_last_seg_path))

            result = agent.run(
                f"{message}\n\nCall final_answer() with your response.",
                images=context_images if context_images else None,
                reset=False,
            )
            result = str(result)

        # ── FIRST ANALYSIS: two-step triage + segmentation ───────────
        else:
            task_images = [image] if image is not None else []

            task = (
                f"{message}\n\nThe image file is located at: {image_path}"
                if message else
                "Identify the imaging modality and run the appropriate segmentation tool. "
                "Return only the path to the segmented image as your final answer.\n\n"
                f"The image file is located at: {image_path}"
            )

            seg_path = agent.run(
                task,
                images=task_images if task_images else None,
                reset=False,
            )
            seg_path = str(seg_path).strip()

            # Backup: if agent didn't return a clean path, scan temp dir
            if not os.path.isfile(seg_path):
                seg_path = find_latest_segmented_image()

            if seg_path and os.path.isfile(seg_path):
                original_pil_image = Image.open(image_path)
                seg_image = Image.open(seg_path)
                _last_seg_path = seg_path

                analysis = agent.run(
                    "You have just segmented the image. "
                    "You are provided two images: the original image and the segmentation "
                    "overlay. Use the original for texture and density analysis, and the overlay "
                    "to confirm for organ boundaries. "
                    "Provide a systematic radiological assessment of the observations in the images such as density "
                    "patterns, textures, and segmentation result identified by colour. Comprehensively look for any "
                    "potential abnormalities. "
                    "Call final_answer() with your complete assessment to finish.",
                    images=[original_pil_image, seg_image],
                    reset=False,
                )
                result = str(analysis)
            else:
                result = str(seg_path)

    except Exception as e:
        result = f"Agent error: {str(e)}"

    chat_history.append({"role": "user", "content": user_msg})
    chat_history.append({"role": "assistant", "content": result})

    display_seg = Image.open(_last_seg_path) if _last_seg_path else None
    return chat_history, display_seg, ""


def reset_conversation():
    """Clear everything and reset agent memory."""
    global _last_seg_path, _last_image_path
    agent.memory.reset()
    _last_seg_path = None
    _last_image_path = None

    return [], None, ""

with gr.Blocks(
    title="Medical Image Triage Agent",
    theme='SebastianBravo/simci_css',
) as demo:

    gr.Markdown(
        """
        # Medical Image Triage Agent
        Upload a medical image and the agent will identify the modality,
        run segmentation, and explain the results.

        *Proof of concept - not for clinical use.*
        """
    )

    with gr.Row():
        with gr.Column(scale=1):
            input_image = gr.Image(
                label="Upload Medical Image",
                type="pil",
                height=400,
            )
            output_image = gr.Image(
                label="Segmentation Result",
                type="pil",
                height=400,
                interactive=False,
            )

        with gr.Column(scale=1):
            chatbot = gr.Chatbot(label="Agent Chat", height=680)
            with gr.Row():
                msg_input = gr.Textbox(
                    label="Message",
                    placeholder="Ask about the image, or just upload and click Analyze...",
                    scale=4,
                    lines=2,
                )
                send_btn = gr.Button("Analyze", variant="primary", scale=1)
            clear_btn = gr.Button("Clear Conversation", variant="secondary")


    send_btn.click(
        fn=run_agent,
        inputs=[input_image, msg_input, chatbot],
        outputs=[chatbot, output_image, msg_input],
    )

    msg_input.submit(
        fn=run_agent,
        inputs=[input_image, msg_input, chatbot],
        outputs=[chatbot, output_image, msg_input],
    )

    clear_btn.click(
        fn=reset_conversation,
        outputs=[chatbot, output_image, msg_input],
    )


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("Starting Medical Image Triage Agent UI")
    print("Open http://127.0.0.1:7860 in your browser")
    print("=" * 60 + "\n")

    demo.launch(
        server_name="127.0.0.1",
        server_port=7860,
        share=False,  # True to get public URL
    )