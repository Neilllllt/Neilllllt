import os
import tarfile
import shutil

def extract_and_combine(base_dir="."):
    combined_dir = os.path.join(base_dir, "combined_output")
    os.makedirs(combined_dir, exist_ok=True)

    for item in os.listdir(base_dir):
        if item.endswith(".tar"):
            tar_path = os.path.join(base_dir, item)
            
            # Create a folder for extraction
            extract_folder = os.path.join(base_dir, item.replace(".tar", ""))
            os.makedirs(extract_folder, exist_ok=True)

            # Extract tar file
            with tarfile.open(tar_path, "r") as tar:
                tar.extractall(path=extract_folder)

            # Walk through extracted files and move them
            for root, _, files in os.walk(extract_folder):
                for file in files:
                    if file.endswith(".pyd"):
                        continue  # skip compiled modules

                    src_path = os.path.join(root, file)
                    
                    dst_path = os.path.join(combined_dir, file)
                    counter = 1
                    while os.path.exists(dst_path):
                        name, ext = os.path.splitext(file)
                        dst_path = os.path.join(combined_dir, f"{name}_{counter}{ext}")
                        counter += 1

                    shutil.move(src_path, dst_path)

    print(f"All files combined into: {combined_dir}")


if __name__ == "__main__":
    extract_and_combine()
    # used for chest Xray subset