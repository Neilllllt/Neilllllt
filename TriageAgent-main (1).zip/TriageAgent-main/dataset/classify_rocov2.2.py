"""
Keyword Matching — Body Region Classifier (Brain / Chest / Breast / Abdominal)

Images that don't match a target region are skipped entirely (not saved).

Usage:
    pip install datasets pillow tqdm
    python classify_rocov2.py

    python classify_rocov2.py --output ./rocov2_sorted

    # Override active regions at runtime:
    python classify_rocov2.py --regions brain chest

Output structure:
    output/
        brain/
        chest/
        breast/
        abdominal/
        classification_results.csv
        summary_report.json
"""

import os
import json
import csv
import re
from pathlib import Path
from collections import Counter

# ── Keyword dictionaries ───────────────────────────────────────────────────────

BODY_REGIONS = {
    "brain": [
        "brain", "cerebral", "cerebell", "cerebellum", "cranial", "intracranial",
        "skull", "ventricle", "cortex", "basal ganglia", "hypothalamus",
        "pituitary", "meninges", "meningeal", "hydrocephalus",
        "subarachnoid", "subdural", "epidural", "corpus callosum",
        "thalamus", "hippocampus", "frontal lobe", "temporal lobe",
        "parietal lobe", "occipital lobe", "cerebrovascular",
        "head mri", "craniotomy", "encephal",
    ],
    "chest": [
        "chest", "lung", "pulmonary", "thorax", "thoracic",
        "pleural", "pneumothorax", "pneumonia", "mediastinum",
        "bronch", "trachea", "diaphragm", "rib", "clavicle",
        "sternum", "pericardium", "pleura", "lobar", "alveol",
        "chest x-ray", "chest ct", "chest radiograph",
    ],
    "breast": [
        "breast", "mammograph", "mammogram", "mastectomy",
        "nipple", "axillary lymph",
        "lobular carcinoma", "ductal carcinoma", "dcis", "lcis",
        "breast cancer", "breast mass", "breast lesion",
    ],
    "abdominal": [
        "abdomen", "abdominal", "liver", "hepatic", "hepatocellular",
        "spleen", "splenic", "pancrea", "bowel", "intestin",
        "colon", "colonic", "sigmoid", "rectum", "rectal",
        "appendix", "appendiceal", "gallbladder", "biliary",
        "peritoneum", "peritoneal", "mesentery", "omentum",
        "stomach", "gastric", "duodenum", "jejunum", "ileum",
        "ascites", "retroperiton",
    ],
}

# Priority order: chest before breast so "chest CT showing breast nodule" → chest
REGION_ORDER = ["brain", "chest", "breast", "abdominal"]

# Regions active by default (all four); override via --regions CLI flag
DEFAULT_REGIONS = list(REGION_ORDER)

# ── Exclusion lists ────────────────────────────────────────────────────────────

EXCLUSIONS: dict[str, list[str]] = {
    "brain": [
        # spine reports firing on "epidural", "subdural", "cortex"
        "lumbar", "thoracic spine", "cervical spine",
        # urinary reports firing on "cortex" (renal cortex)
        "urinary bladder", "kidney", "renal",
        # off-target CT studies where brain keyword is incidental
        "chest ct", "abdominal ct", "thoracic ct",
    ],
    "chest": [
        # dedicated cardiac / vascular studies
        "coronary", "myocardial", "angiograph", "angiogram",
        "echocardiograph", "pericardial effusion",
        # abdominal CTs mentioning diaphragm / bowel near chest field
        "abdominal ct", "abdominal mri",
    ],
    "breast": [
        # metastasis captions where image is of brain, not breast
        "cerebell", "intracranial", "brain mri", "brain ct", "cranial mri",
        # metastasis captions where image is of liver/abdomen, not breast
        "abdominal ct", "abdominal mri", "liver metastas", "hepatic metastas",
        "pancreatic body",
    ],
    "abdominal": [
        # renal / urinary
        "renal", "kidney", "nephro", "ureter", "ureteral",
        "bladder", "urinary", "dialysis", "glomerul",
        "nephritic", "nephrotic",
        # gynaecological / pelvic
        "uterus", "uterine", "ovary", "ovarian", "endometri", "prostate",
        # vascular
        "aneurysm",
        # spine
        "lumbar", "vertebra", "spinal",
    ],
}


# ── Pattern compilation ────────────────────────────────────────────────────────

def _patterns(terms: list[str]) -> list[re.Pattern]:
    """Compile a list of keyword/exclusion terms into prefix-safe regex patterns."""
    return [re.compile(r"\b" + re.escape(t), re.IGNORECASE) for t in terms]


_KW_PATTERNS: dict[str, list[re.Pattern]] = {
    region: _patterns(kws) for region, kws in BODY_REGIONS.items()
}
_EX_PATTERNS: dict[str, list[re.Pattern]] = {
    region: _patterns(exs) for region, exs in EXCLUSIONS.items()
}


# ── Classifier ─────────────────────────────────────────────────────────────────

def classify_caption(caption: str, active_regions: list[str]) -> str | None:
    """
    Return the matched region name, or None if the caption should be skipped.

    Logic:
      1. Walk regions in priority order.
      2. If a primary keyword matches, check exclusions for that region.
         - Any exclusion hit → reject this region and keep walking.
      3. If no region survives → return None (image is skipped entirely).
    """
    text = re.sub(r"[^\w\s]", " ", caption.lower())

    for region in REGION_ORDER:
        if region not in active_regions:
            continue
        if not any(p.search(text) for p in _KW_PATTERNS[region]):
            continue
        if any(p.search(text) for p in _EX_PATTERNS.get(region, [])):
            continue  # exclusion hit — try next region
        return region

    return None  # no region survived → skip


# ── Main pipeline ──────────────────────────────────────────────────────────────

def run(
    output_dir: str = "output",
    splits: tuple = ("train", "validation", "test"),
    save_images: bool = True,
    active_regions: list[str] = None,
):
    if active_regions is None:
        active_regions = DEFAULT_REGIONS

    try:
        from datasets import load_dataset
    except ImportError:
        raise SystemExit("Please install: pip install datasets pillow tqdm")

    from tqdm import tqdm

    out = Path(output_dir)
    for region in active_regions:
        (out / region).mkdir(parents=True, exist_ok=True)

    csv_path = out / "classification_results.csv"
    json_path = out / "summary_report.json"

    region_counter: Counter = Counter()
    split_region_counter: dict = {}
    total_seen = 0
    total_saved = 0

    with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(
            csvfile,
            fieldnames=["split", "image_id", "body_region", "caption", "cui"],
        )
        writer.writeheader()

        for split in splits:
            print(f"\n── Loading split: {split} ──")
            try:
                ds = load_dataset(
                    "eltorio/ROCOv2-radiology",
                    split=split,
                    trust_remote_code=True,
                )
            except Exception as e:
                print(f"  Could not load split '{split}': {e}")
                continue

            split_counter: Counter = Counter()

            for example in tqdm(ds, desc=f"Classifying {split}"):
                caption = example.get("caption", "") or ""
                image_id = example.get("image_id", f"img_{total_seen}")
                cui = example.get("cui", [])
                total_seen += 1

                region = classify_caption(caption, active_regions)
                if region is None:
                    continue  # skip non-matching images entirely

                region_counter[region] += 1
                split_counter[region] += 1
                total_saved += 1

                writer.writerow({
                    "split": split,
                    "image_id": image_id,
                    "body_region": region,
                    "caption": caption,
                    "cui": "|".join(cui) if isinstance(cui, list) else str(cui),
                })

                if save_images:
                    img = example.get("image")
                    if img is not None:
                        img_path = out / region / f"{split}_{image_id}.jpg"
                        try:
                            img.save(img_path, format="JPEG", quality=90)
                        except Exception:
                            img.save(img_path)

            split_region_counter[split] = dict(split_counter)
            split_total = sum(split_counter.values())
            print(f"  Split '{split}' breakdown (saved {split_total:,} / {len(ds):,}):")
            for r, n in sorted(split_counter.items(), key=lambda x: -x[1]):
                pct = 100 * n / len(ds)
                print(f"    {r:<20} {n:>6,}  ({pct:.1f}%)")

    summary = {
        "active_regions": active_regions,
        "total_seen": total_seen,
        "total_saved": total_saved,
        "skipped": total_seen - total_saved,
        "pct_saved": round(100 * total_saved / max(total_seen, 1), 2),
        "overall": dict(region_counter),
        "by_split": split_region_counter,
    }
    with open(json_path, "w") as f:
        json.dump(summary, f, indent=2)

    print("\nDONE:")
    print(f"  Total seen  : {total_seen:,}")
    print(f"  Saved       : {total_saved:,}  ({summary['pct_saved']}%)")
    print(f"  Skipped     : {summary['skipped']:,}")
    print(f"\n  Results CSV  → {csv_path}")
    print(f"  Summary JSON → {json_path}")
    if save_images:
        print(f"  Images       → {out}/<region>/")


# ── Self-test ──────────────────────────────────────────────────────────────────

def test_classifier():
    samples = [
        # ── Should match ──────────────────────────────────────────────────────
        ("Brain MRI showing hyperintensities in basal ganglia",                                    "brain",     True),
        ("Cerebellar metastasis in a glioblastoma patient",                                        "brain",     True),  # cerebell prefix
        ("Chest CT scan showing ground-glass opacities",                                           "chest",     True),
        ("Computed tomography of the chest showing right breast nodule",                           "chest",     True),  # chest wins over breast
        ("Chest radiograph with calcification in the right heart border",                          "chest",     True),  # heart mention but not cardiac study
        ("Grey-scale image of invasive lobular carcinoma",                                         "breast",    True),
        ("Bilateral mammography shows a density asymmetry in the upper quadrant",                  "breast",    True),  # mammogram keeps breast even with abdominal exclusions
        ("Abdominal CT showing hepatomegaly",                                                      "abdominal", True),
        # ── Exclusions — should be skipped (None) ────────────────────────────
        ("Cerebellar localizations of a HR-positive/HER2-negative breast cancer",                 "brain",     True),  # cerebell excluded from breast → falls through to brain (it IS a brain image)
        ("Acquired renal cysts in end-stage renal failure with peritoneal dialysis",               None,        True),  # renal excludes abdominal
        ("CT of the abdomen showing a fatty mass at the center of the transplant kidney",          None,        True),  # kidney excludes abdominal
        ("Enhanced CT showing a right renal tumor that invades the pancreas",                      None,        True),  # renal excludes abdominal
        ("Left coronary angiography showing coronary arteriovenous fistulas",                      None,        True),  # angiography excludes chest
        ("Sagittal MRI of the cervical spine demonstrated nodular contrast enhancement",           None,        True),  # not in any active region
        ("Lumbar spine MRI showing a cystic lesion in the anterior epidural space",                None,        True),  # lumbar excludes brain (epidural)
        ("X-ray hip. Crescent sign.",                                                              None,        True),  # not in any active region
        ("Abdominal CT showing a large aortic aneurysm",                                           None,        True),  # aneurysm excludes abdominal
        ("An abdominal CT scan revealed a mass in the pancreatic body in a breast cancer patient", "abdominal", True),  # pancreatic body excludes breast → falls through to abdominal (it IS an abdominal CT)
    ]

    print("── Classifier self-test ──")
    correct = 0
    for caption, expected, _ in samples:
        got = classify_caption(caption, DEFAULT_REGIONS)
        status = "✓" if got == expected else f"✗ (expected {expected})"
        print(f"  [{status}] {str(got):<20} | {caption[:65]}")
        if got == expected:
            correct += 1
    print(f"\n  {correct}/{len(samples)} correct\n")


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Classify ROCOv2 CT images by body region (brain/chest/breast/abdominal)"
    )
    parser.add_argument("--output", default="output",
                        help="Output directory (default: ./output)")
    parser.add_argument("--splits", nargs="+", default=["train", "validation", "test"],
                        help="Dataset splits to process")
    parser.add_argument("--regions", nargs="+", default=DEFAULT_REGIONS,
                        choices=list(BODY_REGIONS.keys()),
                        help="Active regions to classify (default: all four)")
    parser.add_argument("--no-images", action="store_true",
                        help="Skip saving image files (CSV/JSON only — much faster)")
    parser.add_argument("--test", action="store_true",
                        help="Run classifier self-test only (no HF download)")
    args = parser.parse_args()

    if args.test:
        test_classifier()
    else:
        test_classifier()
        run(
            output_dir=args.output,
            splits=args.splits,
            save_images=not args.no_images,
            active_regions=args.regions,
        )