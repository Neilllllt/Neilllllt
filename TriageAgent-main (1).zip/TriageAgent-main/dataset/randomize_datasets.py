"""
  - Sampling N images per dataset
  - Shuffling ALL sampled images across ALL datasets together first
  - Only THEN assigning sequential filenames (img_00001.png, ...)
    so numeric order carries zero modality signal
  - Converting to PNG and stripping all EXIF/IPTC/PNG metadata on save
  - Handling DICOM files (reads pixel data only, discards all tags)
  - Writing a ground truth manifest CSV (for your eval harness only,
    never exposed to the agent)

Supported input formats: .dcm, .jpg, .jpeg, .png, .bmp, .tif, .tiff

Usage:
    python randomize_datasets.py \
        --output_dir ./agent_eval/images \
        --manifest  ./agent_eval/ground_truth.csv \
        --sample_size 150 \
        --datasets \
            brain_mri:./raw/brain_tumor_mri \
            chest_xray:./raw/NIH_ChestXray14 \
            breast_ultrasound:./raw/BUSI \
            abdominal_ct:./raw/LIDC-IDRI \
            dermatology:./raw/HAM10000

For rocov2 instead: 
    python randomize_datasets.py \
    --output_dir ./agent_eval/images \
    --manifest   ./agent_eval/ground_truth.csv \
    --sample_size 150 \
    --datasets \
        brain:./rocov2_sorted/brain \
        head_face:./rocov2_sorted/head_face \
        chest:./rocov2_sorted/chest \
        cardiac:./rocov2_sorted/cardiac \
        abdomen:./rocov2_sorted/abdomen \
        renal:./rocov2_sorted/renal \
        spine:./rocov2_sorted/spine \
        pelvis:./rocov2_sorted/pelvis \
        limbs:./rocov2_sorted/limbs \
        musculoskeletal:./rocov2_sorted/musculoskeletal \
        neck:./rocov2_sorted/neck \
        breast:./rocov2_sorted/breast


    python randomize_datasets.py \
    --output_dir ./agent_eval/images \
    --manifest   ./agent_eval/ground_truth.csv \
    --sample_size 150 \
    --datasets \
        brain:./rocov2_sorted/brain \
        chest:./rocov2_sorted/chest \
        abdominal:./rocov2_sorted/abdominal \
        breast:./rocov2_sorted/breast
    
"""

import csv
import argparse
import random
import warnings
from pathlib import Path
from collections import Counter

warnings.filterwarnings("ignore")  # suppress PIL decompression warnings

# ── dependencies ───────────────────────────────────────────────────────────────
try:
    from PIL import Image
except ImportError:
    raise SystemExit(
        "Missing Pillow. Install with:\n"
        "  pip install Pillow\n"
        "  pip install pydicom numpy   # only needed for .dcm files"
    )

SUPPORTED_EXTENSIONS = {".dcm", ".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


# ── DICOM handling ─────────────────────────────────────────────────────────────

def dicom_to_pil(dcm_path: Path) -> Image.Image:
    """
    Read a DICOM file and return a PIL Image.
    Only pixel data is used — all DICOM tags (including the Modality tag) are
    discarded, so no metadata leaks through.
    """
    try:
        import pydicom
        import numpy as np
    except ImportError:
        raise SystemExit(
            "pydicom and numpy are required for DICOM files.\n"
            "Install with:  pip install pydicom numpy"
        )

    ds = pydicom.dcmread(str(dcm_path))
    arr = ds.pixel_array.astype(float)

    # Normalise pixel values to 0-255
    lo, hi = arr.min(), arr.max()
    arr = ((arr - lo) / (hi - lo) * 255.0) if hi > lo else (arr * 0.0)
    arr = arr.astype("uint8")

    # Multi-frame volume → take the middle frame as a representative 2D slice
    if arr.ndim == 3 and arr.shape[0] > 1:
        arr = arr[arr.shape[0] // 2]
    elif arr.ndim == 3:
        arr = arr[0]

    mode = "L" if arr.ndim == 2 else "RGB"
    return Image.fromarray(arr, mode=mode).convert("RGB")


# ── metadata stripping ─────────────────────────────────────────────────────────

def save_clean_png(img: Image.Image, dest: Path) -> None:
    """
    Save image as a metadata-free PNG.

    Strategy: re-encode through raw pixel bytes before saving.
    This ensures no EXIF, IPTC, XMP, or PNG tEXt/iTXt/zTXt chunks survive,
    because we never pass the original image's .info dict to the encoder.
    """
    if img.mode not in ("RGB", "L"):
        img = img.convert("RGB")
    # Roundtrip through bytes to drop the .info dict entirely
    clean = Image.frombytes(img.mode, img.size, img.tobytes())
    clean.info = {}
    # pnginfo=None guarantees no ancillary PNG chunks are written
    clean.save(str(dest), format="PNG", pnginfo=None)


# ── file discovery & sampling ──────────────────────────────────────────────────

def find_images(root: Path) -> list[Path]:
    """Recursively find all supported image files under root."""
    return [
        p for p in root.rglob("*")
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS
    ]


def sample_files(files: list[Path], n: int, seed: int) -> list[Path]:
    """Return up to n files sampled without replacement."""
    rng = random.Random(seed)
    return rng.sample(files, min(n, len(files)))


# ── Stage 1: collect all samples (no disk writes yet) ─────────────────────────

def collect_all_samples(
    datasets: list[tuple[str, Path]],
    sample_size: int,
    seed: int,
) -> list[dict]:
    """
    For each dataset, find images and sample up to sample_size.
    Returns a flat list of record dicts — nothing written to disk yet.
    Each record: {modality, source_dataset, original_filename, src_path}
    """
    records = []

    print("Step 1 — Collecting samples from each dataset...")
    for modality_label, source_dir in datasets:
        if not source_dir.exists():
            print(f"  [SKIP] Directory not found: {source_dir}")
            continue

        all_files = find_images(source_dir)
        if not all_files:
            print(f"  [SKIP] No supported images found in: {source_dir}")
            continue

        sampled = sample_files(all_files, sample_size, seed=seed)
        print(f"  {modality_label:<25} {len(all_files):>6} found  →  {len(sampled)} sampled")

        for path in sampled:
            records.append({
                "modality": modality_label,
                "source_dataset": source_dir.name,
                "original_filename": path.name,
                "src_path": path,
            })

    print(f"\n  {len(records)} total images collected.\n")
    return records


# ── Stage 2: shuffle, THEN number and write ────────────────────────────────────

def write_shuffled_images(
    records: list[dict],
    output_dir: Path,
    seed: int,
) -> list[dict]:
    """
    Shuffle all records across all modalities, then assign sequential
    filenames in that shuffled order and write PNGs to output_dir.

    This means img_00001 through img_NNNNN have no modality pattern —
    the numeric order is random with respect to modality.

    Returns manifest rows (src_path stripped out).
    """
    # Shuffle ALL records together before any numbering
    rng = random.Random(seed)
    rng.shuffle(records)
    print("Step 2 — Shuffling all images across all modalities...")
    print("  Sequential filenames will be assigned in shuffled order.\n")

    print("Step 3 — Writing anonymised PNGs...")
    manifest_rows = []
    failed = 0

    for idx, rec in enumerate(records, start=1):
        dest_filename = f"img_{idx:05d}.png"
        dest_path = output_dir / dest_filename
        src_path: Path = rec["src_path"]

        try:
            img = dicom_to_pil(src_path) if src_path.suffix.lower() == ".dcm" \
                  else Image.open(str(src_path))
            save_clean_png(img, dest_path)

            manifest_rows.append({
                "filename": dest_filename,
                "modality": rec["modality"],
                "source_dataset": rec["source_dataset"],
                "original_filename": rec["original_filename"],
            })

        except Exception as e:
            print(f"  [ERROR] {src_path.name}: {e}")
            failed += 1

    print(f"  {len(manifest_rows)} images written successfully.")
    if failed:
        print(f"  ⚠  {failed} images failed and were skipped.")
    print()

    return manifest_rows


# ── Stage 3: write manifest ────────────────────────────────────────────────────

def write_manifest(rows: list[dict], manifest_path: Path) -> None:
    """
    Write the ground truth CSV. Keep this file private — the agent never
    sees it. Your eval harness uses it to score predictions.

    Columns: filename, modality, source_dataset, original_filename
    """
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["filename", "modality", "source_dataset", "original_filename"]
    with open(manifest_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


# ── CLI ────────────────────────────────────────────────────────────────────────

def parse_dataset_arg(s: str) -> tuple[str, Path]:
    """Parse 'modality_label:path/to/dir' into (label, Path)."""
    if ":" not in s:
        raise argparse.ArgumentTypeError(
            f"Must be 'label:path/to/dir', got: {s!r}"
        )
    label, path = s.split(":", 1)
    return label.strip(), Path(path.strip())


def main():
    parser = argparse.ArgumentParser(
        description="Anonymise and flatten medical imaging datasets for agent evaluation.",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument(
        "--datasets", nargs="+", metavar="LABEL:PATH", required=True,
        help=(
            "One or more datasets as 'modality_label:path/to/dir'.\n"
            "Example:\n"
            "  brain_mri:./raw/brain_tumor_mri\n"
            "  chest_xray:./raw/NIH_ChestXray14"
        ),
    )
    parser.add_argument(
        "--output_dir", type=Path, default=Path("./agent_eval/images"),
        help="Flat folder for all anonymised PNGs (default: ./agent_eval/images)",
    )
    parser.add_argument(
        "--manifest", type=Path, default=Path("./agent_eval/ground_truth.csv"),
        help="Path for the ground truth manifest CSV (default: ./agent_eval/ground_truth.csv)",
    )
    parser.add_argument(
        "--sample_size", type=int, default=150,
        help="Max images to sample per dataset (default: 150)",
    )
    parser.add_argument(
        "--seed", type=int, default=42,
        help="Random seed for reproducible sampling and shuffling (default: 42)",
    )

    args = parser.parse_args()
    datasets = [parse_dataset_arg(s) for s in args.datasets]
    args.output_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n{'='*58}")
    print(f"  Medical Imaging Dataset Preprocessor")
    print(f"{'='*58}")
    print(f"  Output dir : {args.output_dir}")
    print(f"  Manifest   : {args.manifest}")
    print(f"  Sample size: {args.sample_size} per dataset")
    print(f"  Seed       : {args.seed}")
    print(f"{'='*58}\n")

    # Stage 1: collect samples from all datasets (no writes yet)
    records = collect_all_samples(datasets, args.sample_size, seed=args.seed)
    if not records:
        print("No images found. Check your --datasets paths and try again.")
        return

    # Stage 2: shuffle across all modalities, then write with sequential names
    manifest_rows = write_shuffled_images(records, args.output_dir, seed=args.seed)

    # Stage 3: write ground truth manifest
    write_manifest(manifest_rows, args.manifest)

    # Summary
    print(f"{'='*58}")
    print(f"  Done.")
    print(f"  {len(manifest_rows)} images → {args.output_dir}")
    print(f"  Manifest   → {args.manifest}")
    print(f"{'='*58}\n")

    counts = Counter(r["modality"] for r in manifest_rows)
    print("  Per-modality counts in final output:")
    for label, count in sorted(counts.items()):
        print(f"    {label:<25} {count:>4} images")
    print()


if __name__ == "__main__":
    main()