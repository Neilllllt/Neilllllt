"""
Keyword Matching

Usage:
    pip install datasets pillow tqdm
    python classify_rocov2.py

    python classify_rocov2.py --output ./rocov2_sorted 

Output structure:
    output/
        brain/
        chest/
        abdomen/
        spine/
        pelvis/
        limbs/
        neck/
        breast/
        cardiac/
        other/
        classification_results.csv
        summary_report.json
"""

import os
import json
import csv
import re
from pathlib import Path
from collections import defaultdict, Counter

BODY_REGIONS = {
    "brain": [
        # "head" removed — too ambiguous (head CT can mean face/neck).
        "brain", "cerebral", "cerebellum", "cranial", "intracranial",
        "skull", "ventricle", "cortex", "basal ganglia", "hypothalamus",
        "pituitary", "meninges", "meningeal", "hydrocephalus",
        "subarachnoid", "subdural", "epidural", "corpus callosum",
        "thalamus", "hippocampus", "frontal lobe", "temporal lobe",
        "parietal lobe", "occipital lobe", "cerebrovascular",
        "head mri", "craniotomy", "encephal",
    ],
    "chest": [
        # chest/lung keywords come BEFORE breast so "chest CT showing breast nodule" stays in chest.
        "chest", "lung", "pulmonary", "thorax", "thoracic",
        "pleural", "pneumothorax", "pneumonia", "mediastinum",
        "bronch", "trachea", "diaphragm", "rib", "clavicle",
        "sternum", "pericardium", "pleura", "lobar", "alveol",
        "chest x-ray", "chest ct", "chest radiograph",
    ],
    "cardiac": [
        "cardiac", "heart", "myocardial", "ventricul", "atri",
        "coronary", "aortic valve", "mitral", "tricuspid",
        "pericardial", "cardiomegaly", "echocardiograph",
        "angiograph", "angiogram", "aorta", "aortic",
        "vascular", "artery", "arterial", "venous", "vessel",
        "carotid", "femoral artery", "iliac artery",
    ],
    "abdomen": [
        "abdomen", "abdominal", "liver", "hepatic", "hepatocellular",
        "spleen", "splenic", "pancrea", "bowel", "intestin",
        "colon", "colonic", "sigmoid", "rectum", "rectal",
        "appendix", "appendiceal", "gallbladder", "biliary",
        "peritoneum", "peritoneal", "mesentery", "omentum",
        "stomach", "gastric", "duodenum", "jejunum", "ileum",
        "ascites", "retroperiton",
    ],
    "renal": [
        "renal", "kidney", "nephro", "ureter", "ureteral",
        "bladder", "urinary", "urology", "urograph",
        "adrenal", "pelvis renal",
    ],
    "spine": [
        "spine", "spinal", "vertebra", "vertebral", "disc",
        "lumbar", "sacrum", "sacral", "coccyx",
        "cervical spine", "thoracic spine", "intervertebral",
        "spinal cord", "cauda equina", "myelograph",
        "spondyl", "kyphosis", "scoliosis", "stenosis canal",
    ],
    "pelvis": [
        "pelvis", "pelvic", "hip", "sacroiliac", "iliac bone",
        "acetabulum", "femoral head", "pubic", "ischium",
        "ovary", "ovarian", "uterus", "uterine", "cervix",
        "prostate", "scrotal", "testicular",
    ],
    "limbs": [
        "femur", "tibia", "fibula", "patella", "knee",
        "humerus", "radius", "ulna", "shoulder", "elbow",
        "wrist", "carpal", "metacarpal", "phalanx",
        "ankle", "calcaneum", "calcaneus", "tarsal", "metatarsal",
        "foot", "hand", "finger", "toe",
        "upper limb", "lower limb", "extremity",
        "long bone", "fracture", "osteonecrosis",
    ],
    "neck": [
        "neck", "thyroid", "larynx", "laryngeal",
        "pharynx", "pharyngeal", "hypopharynx", "oropharynx",
        "nasopharynx", "parotid", "submandibular", "salivary",
        "cervical lymph", "cervical mass",
    ],
    "breast": [
        # Specific breast-pathology terms added so non-"breast"-word captions
        # (e.g. "lobular carcinoma", "ductal carcinoma") still match.
        "breast", "mammograph", "mammogram", "mastectomy",
        "nipple", "axillary lymph",
        "lobular carcinoma", "ductal carcinoma", "dcis", "lcis",
        "breast cancer", "breast mass", "breast lesion",
    ],
    "musculoskeletal": [
        "bone", "skeletal", "musculoskeletal", "cartilage",
        "joint", "osteo", "articular", "ligament", "tendon",
        "muscle", "soft tissue mass", "sarcoma",
    ],
    "head_face": [
        # "head ct" added here (without "mri") so plain head CTs default to
        # head_face rather than brain unless a brain structure is named.
        "head ct", "orbit", "orbital", "nasal", "sinus", "paranasal",
        "maxill", "mandible", "jaw", "dental", "teeth",
        "ear", "mastoid", "temporal bone",
        "face", "facial", "eye", "ocular", "retina",
    ],
}

# Priority order: more specific regions first
REGION_ORDER = [
    "brain", "head_face", "neck", "chest", "breast", "cardiac",
    "abdomen", "renal",
    "spine", "pelvis", "limbs", "musculoskeletal",
    "other",
]


# classifier func
def classify_caption(caption: str) -> str:
    text = caption.lower()
    # Remove punctuation noise
    text = re.sub(r"[^\w\s]", " ", text)

    for region in REGION_ORDER:
        if region == "other":
            break
        keywords = BODY_REGIONS.get(region, [])
        for kw in keywords:
            # Word-boundary aware match
            pattern = r"\b" + re.escape(kw) + r"\b"
            if re.search(pattern, text):
                return region
    return "other"

def run(output_dir: str = "output", splits=("train", "validation", "test"),
        save_images: bool = True):
    """
    Load ROCOv2, classify every example, optionally save images to subfolders,
    and write a CSV + JSON summary.
    """
    try:
        from datasets import load_dataset
    except ImportError:
        raise SystemExit("Please install: pip install datasets pillow tqdm")

    from tqdm import tqdm

    out = Path(output_dir)

    # Create region subdirs
    all_regions = REGION_ORDER[:-1] + ["other"]
    for region in all_regions:
        (out / region).mkdir(parents=True, exist_ok=True)

    csv_path = out / "classification_results.csv"
    json_path = out / "summary_report.json"

    region_counter: Counter = Counter()
    split_region_counter: dict = {}
    total = 0

    with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(
            csvfile,
            fieldnames=["split", "image_id", "body_region", "caption", "cui"],
        )
        writer.writeheader()

        for split in splits:
            print(f"\n── Loading split: {split} ──")
            try:
                ds = load_dataset(
                    "eltorio/ROCOv2-radiology",
                    split=split,
                    trust_remote_code=True,
                )
            except Exception as e:
                print(f"  Could not load split '{split}': {e}")
                continue

            split_counter: Counter = Counter()

            for example in tqdm(ds, desc=f"Classifying {split}"):
                caption = example.get("caption", "") or ""
                image_id = example.get("image_id", f"img_{total}")
                cui = example.get("cui", [])
                region = classify_caption(caption)

                region_counter[region] += 1
                split_counter[region] += 1
                total += 1

                writer.writerow({
                    "split": split,
                    "image_id": image_id,
                    "body_region": region,
                    "caption": caption,
                    "cui": "|".join(cui) if isinstance(cui, list) else str(cui),
                })

                # Save image file
                if save_images:
                    img = example.get("image")
                    if img is not None:
                        img_path = out / region / f"{split}_{image_id}.jpg"
                        try:
                            img.save(img_path, format="JPEG", quality=90)
                        except Exception:
                            img.save(img_path)

            split_region_counter[split] = dict(split_counter)
            print(f"  Split '{split}' breakdown:")
            for r, n in sorted(split_counter.items(), key=lambda x: -x[1]):
                pct = 100 * n / len(ds)
                print(f"    {r:<20} {n:>6,}  ({pct:.1f}%)")

    # Summary JSON
    summary = {
        "total_images": total,
        "overall": dict(region_counter),
        "by_split": split_region_counter,
        "coverage": {
            "classified": total - region_counter.get("other", 0),
            "unclassified": region_counter.get("other", 0),
            "pct_classified": round(
                100 * (total - region_counter.get("other", 0)) / max(total, 1), 2
            ),
        },
    }
    with open(json_path, "w") as f:
        json.dump(summary, f, indent=2)

    print("\nDONE: ")
    print(f"  Total processed : {total:,}")
    print(f"  Classified       : {summary['coverage']['classified']:,}  "
          f"({summary['coverage']['pct_classified']}%)")
    print(f"  Unclassified     : {summary['coverage']['unclassified']:,}")
    print(f"\n  Results CSV  → {csv_path}")
    print(f"  Summary JSON → {json_path}")
    print(f"  Images       → {out}/<region>/")


# Test mode

def test_classifier():
    """Quick sanity check using the sample captions from the dataset page."""
    samples = [
        ("Head CT demonstrating left parotiditis.", "head_face"),
        ("Brain MRI Flaire image showing hyperintensities in basal ganglias", "brain"),
        ("Chest CT scan showing ground-glass opacities", "chest"),
        ("Computed tomography of the chest showing the right breast nodule", "chest"),
        ("Left coronary angiography showing coronary arteriovenous fistulas", "cardiac"),
        ("Abdominal CT showing hepatomegaly", "abdomen"),
        ("Sagittal MRI of the cervical spine demonstrated nodular contrast enhancement", "spine"),
        ("X-ray hip. Crescent sign.", "pelvis"),
        ("Bone scintigraphy. Increased uptake in bilateral distal tibia", "limbs"),
        ("Ultrasonogram of thyroid showing calcifications", "neck"),
        ("Grey-scale sonographic image of the invasive lobular carcinoma", "breast"),
        ("Computed tomography urography. The right kidney is ectopically placed", "renal"),
    ]

    print("── Classifier self-test ──")
    correct = 0
    for caption, expected in samples:
        got = classify_caption(caption)
        status = "✓" if got == expected else f"✗ (expected {expected})"
        print(f"  [{status}] {got:<20} | {caption[:60]}")
        if got == expected:
            correct += 1
    print(f"\n  {correct}/{len(samples)} correct\n")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Classify ROCOv2 images by body region")
    parser.add_argument("--output", default="output", help="Output directory (default: ./output)")
    parser.add_argument("--splits", nargs="+", default=["train", "validation", "test"],
                        help="Dataset splits to process")
    parser.add_argument("--no-images", action="store_true",
                        help="Skip saving image files (CSV/JSON only — much faster)")
    parser.add_argument("--test", action="store_true",
                        help="Run classifier self-test only (no HF download)")
    args = parser.parse_args()

    if args.test:
        test_classifier()
    else:
        test_classifier()
        run(
            output_dir=args.output,
            splits=args.splits,
            save_images=not args.no_images,
        )