import os
import tempfile
import numpy as np
from PIL import Image

from smolagents import tool


@tool
def segment_brain_mri(image_path: str) -> str:
    """
    Runs brain segmentation on a 2D brain MRI image.

    This tool should ONLY be used when the input image has been identified as a brain MRI. It segments the brain
    sections and returns a path to the overlayed result image.

    Args:
        image_path: Path to the brain MRI image file.

    Returns:
        Path to the segmented brain MRI image.
    """
    print('Running brain MRI segmentation.')
    return ''