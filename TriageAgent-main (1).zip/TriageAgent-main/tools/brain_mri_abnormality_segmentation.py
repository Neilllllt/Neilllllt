import os
import tempfile
import numpy as np
import torch
from PIL import Image
from smolagents import tool
from torchvision import transforms


REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# MODEL_CACHE_DIR = os.environ.get(
#     "TRIAGE_AGENT_MODEL_CACHE",
#     os.path.join(REPO_ROOT, ".model-cache"),
# )
# OUTPUT_DIR = os.environ.get(
#     "TRIAGE_AGENT_OUTPUT_DIR",
#     os.path.join(REPO_ROOT, "outputs"),
# )
_MODEL = None


def _device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def _get_model() -> torch.nn.Module:
    """Load and cache the public pretrained brain MRI U-Net."""
    global _MODEL
    if _MODEL is None:
        # os.makedirs(MODEL_CACHE_DIR, exist_ok=True)
        # torch.hub.set_dir(MODEL_CACHE_DIR)
        model = torch.hub.load(
            "mateuszbuda/brain-segmentation-pytorch",
            "unet",
            in_channels=3,
            out_channels=1,
            init_features=32,
            pretrained=True,
            trust_repo=True,
        )
        model.to(_device()).eval()
        _MODEL = model
    return _MODEL


def _preprocess(image_path: str) -> tuple[torch.Tensor, Image.Image]:
    original = Image.open(image_path).convert("RGB")
    model_image = original.resize((256, 256), Image.LANCZOS)
    image_np = np.array(model_image, dtype=np.float32)
    mean = image_np.mean(axis=(0, 1)) / 255.0
    std = image_np.std(axis=(0, 1)) / 255.0
    std = np.where(std < 1e-6, 1.0, std)

    preprocess = transforms.Compose(
        [
            transforms.ToTensor(),
            transforms.Normalize(mean=mean.tolist(), std=std.tolist()),
        ]
    )
    return preprocess(model_image).unsqueeze(0), original


def _build_overlay(original: Image.Image, mask: np.ndarray, alpha: float = 0.45) -> Image.Image:
    base = original.convert("RGB")
    if mask.shape != (base.height, base.width):
        mask_image = Image.fromarray(mask.astype(np.uint8) * 255, mode="L")
        mask = np.array(mask_image.resize(base.size, Image.NEAREST)) > 0

    overlay = np.array(base, dtype=np.float32)
    color = np.array([255, 64, 64], dtype=np.float32)
    overlay = np.where(mask[..., None], overlay * (1 - alpha) + color * alpha, overlay)
    return Image.fromarray(overlay.astype(np.uint8))


@tool
def segment_brain_mri_abnormality(image_path: str, mask_threshold: float = 0.5) -> str:
    """
    Runs public pretrained brain MRI abnormality segmentation with a U-Net
    from mateuszbuda/brain-segmentation-pytorch.

    This tool should ONLY be used for 2D brain MRI slices. The pretrained
    model was trained for abnormality segmentation on 3-channel brain MRI
    slices. For a single uploaded MRI image, this tool converts it to RGB,
    z-score normalizes channels, predicts an abnormality mask, and returns
    a red mask overlay on the original image. The language model should
    handle interpretation/classification from the original and overlay images.

    Args:
        image_path: Path to the brain MRI image file.
        mask_threshold: Probability threshold for converting the predicted
            abnormality map into a binary mask.

    Returns:
        Path to the segmented overlay image.
    """
    print(f"[brain_mri_abnormality] Loading image: {image_path}")

    tensor, image = _preprocess(image_path)
    model = _get_model()
    device = next(model.parameters()).device

    with torch.no_grad():
        output = model(tensor.to(device))
        probability = output[0, 0].detach().cpu().numpy()

    mask = probability > mask_threshold

    overlay = _build_overlay(image, mask)
    out_path = os.path.join(tempfile.gettempdir(), "brain_mri_abnormality_segmented.png")
    overlay.save(out_path)

    print(f"Brain MRI abnormality segmentation complete. Overlay saved to: {out_path}")
    return out_path
