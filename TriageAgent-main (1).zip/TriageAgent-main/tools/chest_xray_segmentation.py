import os
import tempfile
import numpy as np
from PIL import Image

import torch
import torchvision.transforms as transforms
from scipy import ndimage

from smolagents import tool


# ── Lazy-loaded singleton so the model is only downloaded / built once ────────
_SEG_MODEL = None

# PSPNet outputs 14 channels. We only use channels 4 and 5 (lungs).
# Channel indices in the full PSPNet output:
#   0: Left Clavicle,  1: Right Clavicle,  2: Left Scapula,  3: Right Scapula,
#   4: Left Lung,      5: Right Lung,      6: Left Hilus,    7: Right Hilus,
#   8: Heart,          9: Aorta,          10: Diaphragm,    11: Mediastinum,
#  12: Weasand,       13: Spine
LUNG_CHANNELS = {
    4: ("Left Lung",  (  86, 180, 233)),   # blue
    5: ("Right Lung", ( 86, 180, 233)),   # blue
}


def _get_model():
    """Return the cached PSPNet; download weights on first call."""
    global _SEG_MODEL
    if _SEG_MODEL is None:
        import torchxrayvision as xrv
        _SEG_MODEL = xrv.baseline_models.chestx_det.PSPNet()
        _SEG_MODEL.eval()
        if torch.cuda.is_available():
            _SEG_MODEL = _SEG_MODEL.cuda()
    return _SEG_MODEL


def _preprocess(image_path: str) -> torch.Tensor:
    """
    Load a chest X-ray from disk and convert it into the tensor format
    expected by torchxrayvision models:
        • single-channel grayscale
        • pixel range [-1024, 1024]
        • resized to 512 × 512
        • shape (1, 1, 512, 512)
    """
    import torchxrayvision as xrv

    img = Image.open(image_path).convert("L")  # grayscale
    img_np = np.array(img, dtype=np.float32)

    # xrv convention: map [0, 255] → [-1024, 1024]
    img_np = xrv.datasets.normalize(img_np, 255)

    # (H, W) → (1, H, W)  – single colour channel
    if img_np.ndim == 2:
        img_np = img_np[None, ...]

    # Resize to 512×512 (PSPNet's native resolution)
    tensor = torch.from_numpy(img_np).unsqueeze(0)  # (1, 1, H, W)
    tensor = torch.nn.functional.interpolate(
        tensor, size=(512, 512), mode="bilinear", align_corners=False
    )
    return tensor


def _postprocess_mask(
    lung_prob: np.ndarray,
    all_masks: np.ndarray,
    threshold: float = 0.7,
) -> np.ndarray:
    """
    Refine a raw lung probability map into a clean binary mask.

    Steps:
        1. Gaussian blur to smooth noisy edges
        2. Threshold with a strict cutoff to tighten boundaries
        3. Subtract overlapping non-lung structures (heart, mediastinum,
           aorta, spine) that the model often bleeds into
        4. Morphological opening to remove small spurs at boundaries
        5. Morphological closing to fill small internal holes
        6. Keep only the largest connected component

    Args:
        lung_prob:  (H, W) float array – lung channel probabilities.
        all_masks:  (14, H, W) float array – all 14 channel probabilities,
                    used to subtract overlapping structures.
        threshold:  probability cutoff (default 0.7).

    Returns:
        (H, W) binary uint8 mask (0 or 1).
    """
    # 1. Smooth the probability map
    smoothed = ndimage.gaussian_filter(lung_prob, sigma=2.0)

    # 2. Binarise with a strict threshold
    binary = (smoothed > threshold).astype(np.uint8)

    # 3. Subtract overlapping structures
    #    ch 8 = Heart, ch 9 = Aorta, ch 11 = Mediastinum, ch 13 = Spine
    for ch in [8, 9, 11, 13]:
        overlap = (all_masks[ch] > 0.5).astype(np.uint8)
        binary = binary & (~overlap.astype(bool)).astype(np.uint8)

    # 4. Morphological opening: removes small protrusions at edges
    struct = ndimage.generate_binary_structure(2, 1)
    binary = ndimage.binary_opening(
        binary, structure=struct, iterations=5
    ).astype(np.uint8)

    # 5. Morphological closing: fills small internal holes
    binary = ndimage.binary_closing(
        binary, structure=struct, iterations=3
    ).astype(np.uint8)

    # 6. Keep only the largest connected component
    labelled, num_features = ndimage.label(binary)
    if num_features > 1:
        component_sizes = ndimage.sum(
            binary, labelled, range(1, num_features + 1)
        )
        largest = np.argmax(component_sizes) + 1
        binary = (labelled == largest).astype(np.uint8)

    return binary


def _build_overlay(
    original: Image.Image,
    lung_masks: dict,
    alpha: float = 0.45,
) -> Image.Image:
    """
    Blend coloured lung segmentation masks onto the original greyscale image.

    Args:
        original:    PIL Image (any mode – will be converted to RGB).
        lung_masks:  dict mapping channel index → cleaned binary mask (H, W).
        alpha:       opacity of the overlay.

    Returns:
        A PIL RGB Image with the overlay composited on top.
    """
    base = original.convert("RGB").resize((512, 512), Image.LANCZOS)
    overlay = np.array(base, dtype=np.float32)

    for ch_idx, (name, colour) in LUNG_CHANNELS.items():
        binary = lung_masks[ch_idx].astype(np.float32)
        if binary.sum() == 0:
            continue
        for c in range(3):
            overlay[..., c] = np.where(
                binary,
                overlay[..., c] * (1 - alpha) + colour[c] * alpha,
                overlay[..., c],
            )

    return Image.fromarray(overlay.astype(np.uint8))


# ─────────────────────────────────────────────────────────────────────────────
@tool
def segment_chest_xray(image_path: str) -> str:
    """
    Runs lung segmentation on a chest X-ray image using a pre-trained
    PSPNet from the torchxrayvision library (ChestX-Det weights).

    The model extracts left and right lung fields from the X-ray and
    overlays them in distinct colours (green for left lung, blue for
    right lung) on the original image.  It also reports the percentage
    of the image covered by each lung.

    This tool should ONLY be used when the input image has been identified
    as a **chest X-ray**.  It will not produce meaningful results on brain
    MRIs, CT slices, or other modalities.

    Args:
        image_path: Absolute or relative path to the chest X-ray image file
                    (JPEG, PNG, DICOM-converted PNG, etc.).

    Returns:
        Path to the segmented overlay image (PNG) saved in the system
        temp directory. The filename ends with ``_segmented.png`` so the
        Gradio UI can locate it automatically.
    """
    print(f"[chest_xray_segmentation] Loading image: {image_path}")

    # ── 1. Pre-process ──────────────────────────────────────────────────
    tensor = _preprocess(image_path)
    device = next(_get_model().parameters()).device
    tensor = tensor.to(device)

    # ── 2. Inference ─────────────────────────────────────────────────────
    model = _get_model()
    with torch.no_grad():
        output = model(tensor)          # (1, 14, 512, 512)
        probs = torch.sigmoid(output)   # convert logits → probabilities
        masks = probs[0].cpu().numpy()  # (14, 512, 512)

    # ── 3. Post-process each lung mask ──────────────────────────────────
    lung_masks = {}
    for ch_idx in LUNG_CHANNELS:
        lung_masks[ch_idx] = _postprocess_mask(
            masks[ch_idx], all_masks=masks, threshold=0.7
        )

    # ── 4. Build colour overlay ──────────────────────────────────────────
    original = Image.open(image_path)
    result = _build_overlay(original, lung_masks)

    # ── 5. Save ──────────────────────────────────────────────────────────
    out_path = os.path.join(tempfile.gettempdir(), "chest_xray_segmented.png")
    result.save(out_path)

    # ── 6. Build a short textual summary of detected lung fields ────────
    detected = []
    for ch_idx, (name, _) in LUNG_CHANNELS.items():
        coverage = lung_masks[ch_idx].mean() * 100
        if coverage > 0.5:
            detected.append(f"{name} ({coverage:.1f}%)")

    summary = (
        f"Lung segmentation complete. Overlay saved to: {out_path}\n"
        f"Detected: {', '.join(detected) if detected else 'no lung fields above threshold'}"
    )
    print(summary)
    return out_path