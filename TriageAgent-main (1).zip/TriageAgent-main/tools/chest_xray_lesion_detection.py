import os
import tempfile
import numpy as np
from PIL import Image

import torch
import torch.nn.functional as F

from smolagents import tool


# ── Lazy-loaded model singletons ─────────────────────────────────────────────
_CLS_MODEL = None   # DenseNet – pathology classification (224×224)
_SEG_MODEL = None   # PSPNet  – lung mask for heatmap masking (512×512)

# Lung-related pathologies we report and localise.
# Cardiomegaly, Hernia, Enlarged Cardiomediastinum are excluded because
# they are not intra-pulmonary lesions.
LUNG_PATHOLOGIES = {
    "Atelectasis", "Consolidation", "Infiltration", "Pneumothorax",
    "Edema", "Emphysema", "Fibrosis", "Effusion", "Pneumonia",
    "Pleural_Thickening", "Nodule", "Mass", "Lung Lesion",
    "Lung Opacity",
}


# ─────────────────────────────────────────────────────────────────────────────
# MODEL LOADERS
# ─────────────────────────────────────────────────────────────────────────────
def _get_cls_model():
    """Return the cached DenseNet-121 classifier (all weights)."""
    global _CLS_MODEL
    if _CLS_MODEL is None:
        import torchxrayvision as xrv
        _CLS_MODEL = xrv.models.DenseNet(weights="densenet121-res224-all")
        _CLS_MODEL.eval()
        if torch.cuda.is_available():
            _CLS_MODEL = _CLS_MODEL.cuda()
    return _CLS_MODEL


def _get_seg_model():
    """Return the cached PSPNet (used only for lung masking)."""
    global _SEG_MODEL
    if _SEG_MODEL is None:
        import torchxrayvision as xrv
        _SEG_MODEL = xrv.baseline_models.chestx_det.PSPNet()
        _SEG_MODEL.eval()
        if torch.cuda.is_available():
            _SEG_MODEL = _SEG_MODEL.cuda()
    return _SEG_MODEL


# ─────────────────────────────────────────────────────────────────────────────
# PREPROCESSING
# ─────────────────────────────────────────────────────────────────────────────
def _preprocess(image_path: str, size: int) -> torch.Tensor:
    """
    Load a chest X-ray and return a torchxrayvision-format tensor.

    Returns:
        Tensor of shape (1, 1, size, size) in [-1024, 1024] range.
    """
    import torchxrayvision as xrv

    img = Image.open(image_path).convert("L")
    img_np = np.array(img, dtype=np.float32)
    img_np = xrv.datasets.normalize(img_np, 255)

    if img_np.ndim == 2:
        img_np = img_np[None, ...]

    tensor = torch.from_numpy(img_np).unsqueeze(0)
    tensor = F.interpolate(tensor, size=(size, size),
                           mode="bilinear", align_corners=False)
    return tensor


# ─────────────────────────────────────────────────────────────────────────────
# LUNG MASK (quick, used only to constrain heatmaps)
# ─────────────────────────────────────────────────────────────────────────────
def _get_lung_mask(image_path: str) -> np.ndarray:
    """
    Run PSPNet and return a combined binary lung mask at 512×512.

    Uses a simple 0.5 threshold — this mask is only used to constrain the
    Grad-CAM heatmap to the lung region, so it doesn't need the aggressive
    post-processing of the segmentation tool.
    """
    model = _get_seg_model()
    device = next(model.parameters()).device
    tensor = _preprocess(image_path, size=512).to(device)

    with torch.no_grad():
        probs = torch.sigmoid(model(tensor))
        masks = probs[0].cpu().numpy()   # (14, 512, 512)

    # Channels 4 + 5 = left lung + right lung
    combined = np.clip(masks[4] + masks[5], 0, 1)
    return (combined > 0.5).astype(np.uint8)


# ─────────────────────────────────────────────────────────────────────────────
# GRAD-CAM
# ─────────────────────────────────────────────────────────────────────────────
def _gradcam(model, input_tensor: torch.Tensor, class_idx: int) -> np.ndarray:
    """
    Compute a Grad-CAM heatmap for a given pathology class.

    Hooks into the last convolutional block of the DenseNet to capture
    feature activations and their gradients, then computes a weighted
    spatial map showing where the network focuses for the target class.

    Returns:
        (224, 224) float32 heatmap normalised to [0, 1].
    """
    activations = {}
    gradients = {}

    def fwd_hook(module, inp, out):
        activations["val"] = out.clone()

    def bwd_hook(module, grad_in, grad_out):
        gradients["val"] = grad_out[0].clone()

    # Find the last child of model.features (final DenseBlock + transition)
    target_layer = None
    for _, module in model.features.named_children():
        target_layer = module
    assert target_layer is not None

    fh = target_layer.register_forward_hook(fwd_hook)
    bh = target_layer.register_backward_hook(bwd_hook)

    try:
        inp = input_tensor.clone().detach().requires_grad_(True)
        output = model(inp)                     # (1, 18)
        score = output[0, class_idx]

        model.zero_grad()
        score.backward()

        grads = gradients["val"]                # (1, C, h, w)
        acts = activations["val"]               # (1, C, h, w)
        weights = grads.mean(dim=(2, 3), keepdim=True)
        cam = (weights * acts).sum(dim=1, keepdim=True)
        cam = F.relu(cam)
        cam = F.interpolate(cam, size=(224, 224),
                            mode="bilinear", align_corners=False)
        cam = cam[0, 0].detach().cpu().numpy()

        lo, hi = cam.min(), cam.max()
        if hi - lo > 1e-8:
            cam = (cam - lo) / (hi - lo)
        else:
            cam = np.zeros_like(cam)
    finally:
        fh.remove()
        bh.remove()

    return cam


# ─────────────────────────────────────────────────────────────────────────────
# OVERLAY BUILDER
# ─────────────────────────────────────────────────────────────────────────────
def _build_lesion_overlay(
    original: Image.Image,
    heatmap: np.ndarray,
    alpha: float = 0.55,
) -> Image.Image:
    """
    Overlay a red-to-yellow lesion heatmap onto the original image.

    Args:
        original: PIL Image.
        heatmap:  (512, 512) float32 in [0, 1], masked to lung region.
        alpha:    max opacity of the heatmap.
    """
    base = original.convert("RGB").resize((512, 512), Image.LANCZOS)
    overlay = np.array(base, dtype=np.float32)

    mask = heatmap > 0.25
    if mask.any():
        r = np.clip(heatmap * 255, 0, 255)
        g = np.clip(heatmap * 180, 0, 180)
        b = np.zeros_like(heatmap)
        blend = alpha * heatmap       # intensity-weighted blending
        for c, ch_vals in enumerate([r, g, b]):
            overlay[..., c] = np.where(
                mask,
                overlay[..., c] * (1 - blend) + ch_vals * blend,
                overlay[..., c],
            )

    return Image.fromarray(np.clip(overlay, 0, 255).astype(np.uint8))


# ─────────────────────────────────────────────────────────────────────────────
# TOOL
# ─────────────────────────────────────────────────────────────────────────────
@tool
def detect_chest_xray_lesion(image_path: str) -> str:
    """
    Detects and localises lesions in a chest X-ray image.

    Uses a pre-trained DenseNet-121 classifier (torchxrayvision, trained on
    NIH, PadChest, CheXpert, MIMIC, and other datasets) to screen for 14
    lung-related pathologies: Atelectasis, Consolidation, Infiltration,
    Pneumothorax, Edema, Emphysema, Fibrosis, Effusion, Pneumonia,
    Pleural Thickening, Nodule, Mass, Lung Lesion, and Lung Opacity.

    For every detected pathology, Grad-CAM is computed on the last
    convolutional layer to produce a heatmap showing WHERE in the image
    the lesion is located. The heatmap is masked to the lung region
    (using PSPNet lung segmentation) so only intra-pulmonary findings
    are highlighted.

    The output image overlays a red-to-yellow heatmap on the original
    X-ray. Brighter colour = higher confidence in lesion location.

    This tool should ONLY be used when the input image has been identified
    as a **chest X-ray** and the goal is to detect or localise pathologies
    or lesions.  For anatomical lung segmentation without lesion detection,
    use ``segment_chest_xray`` instead.

    Args:
        image_path: Path to the chest X-ray image file.

    Returns:
        A summary listing detected pathologies and their scores,
        plus the path to the lesion overlay image.
    """
    print(f"[chest_xray_lesion] Loading image: {image_path}")

    # ── 1. Classification ────────────────────────────────────────────────
    cls_model = _get_cls_model()
    device = next(cls_model.parameters()).device
    tensor_224 = _preprocess(image_path, size=224).to(device)

    with torch.no_grad():
        preds = cls_model(tensor_224)
        scores = preds[0].detach().cpu().numpy()

    pathologies = cls_model.pathologies

    # PPV80 thresholds for densenet121-res224-all (from torchxrayvision source).
    # These are tuned so that when a pathology fires, there is ~80% chance it
    # is a true positive — much stricter than op_threshs which fire on everything.
    PPV80 = {
        "Atelectasis": 0.727, "Consolidation": 0.889, "Infiltration": 0.925,
        "Pneumothorax": 0.653, "Edema": 0.687, "Emphysema": 0.461,
        "Fibrosis": 0.727, "Effusion": 0.613, "Pneumonia": 0.988,
        "Pleural_Thickening": 0.620, "Cardiomegaly": 0.663, "Nodule": 0.785,
        "Mass": 0.931, "Hernia": 0.936, "Lung Lesion": 0.679,
        "Fracture": 0.655, "Lung Opacity": 0.616,
        "Enlarged Cardiomediastinum": 0.849,
    }

    detected = []
    for i, (name, score) in enumerate(zip(pathologies, scores)):
        if np.isnan(score) or name not in PPV80:
            continue
        if score > PPV80[name] and name in LUNG_PATHOLOGIES:
            detected.append((name, float(score), i))

    # Sort by score descending and keep only the top 3 findings.
    # This prevents the heatmap from covering the entire lung when
    # multiple marginal detections are aggregated.
    detected.sort(key=lambda x: x[1], reverse=True)
    detected = detected[:3]
    cam_indices = [d[2] for d in detected]
    detected = [(d[0], d[1]) for d in detected]

    # ── 2. Early exit if nothing found ───────────────────────────────────
    if not detected:
        print("[chest_xray_lesion] No pathologies detected.")
        return (
            "Lesion detection complete. "
            "No significant lung pathologies detected above threshold."
        )

    # ── 3. Grad-CAM for each detected pathology ─────────────────────────
    print(f"[chest_xray_lesion] Detected {len(detected)} pathologies, "
          f"computing Grad-CAM...")

    agg_cam = np.zeros((224, 224), dtype=np.float32)
    for idx in cam_indices:
        cam = _gradcam(cls_model, tensor_224, idx)
        agg_cam = np.maximum(agg_cam, cam)

    # Upscale to 512×512
    agg_512 = np.array(
        Image.fromarray(agg_cam).resize((512, 512), Image.BILINEAR)
    )

    # ── 4. Mask heatmap to lung region ───────────────────────────────────
    lung_mask = _get_lung_mask(image_path)
    agg_512 = agg_512 * lung_mask.astype(np.float32)

    mx = agg_512.max()
    if mx > 1e-8:
        agg_512 /= mx

    # ── 5. Build overlay ─────────────────────────────────────────────────
    original = Image.open(image_path)
    result = _build_lesion_overlay(original, agg_512)

    out_path = os.path.join(tempfile.gettempdir(), "chest_xray_lesion.png")
    result.save(out_path)
    print(f"[chest_xray_lesion] Saved overlay → {out_path}")

    # ── 6. Summary ───────────────────────────────────────────────────────
    findings = [f"{name} (score={score:.2f})" for name, score in detected]
    lines = [
        f"Lesion detection complete. Overlay saved to: {out_path}",
        f"Pathologies detected: {', '.join(findings)}",
        "Lesion locations are highlighted in red/yellow on the overlay.",
    ]
    return "\n".join(lines)