import os
import tempfile
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torchvision.transforms as transforms
from PIL import Image, ImageDraw
from smolagents import tool


REPO_ROOT = Path(__file__).resolve().parents[1]
VISION_DIR = Path(os.environ.get("VISION_MODEL_DIR", REPO_ROOT / "VISION-model"))
VIEW_LABELS = ("axial", "coronal", "sagittal")

_VIEW_CLASSIFIER = None
_VIEW_CLASSIFIER_DEVICE = None
_VISION_MODELS = {}


def _device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def _checkpoint_candidates(name: str, env_var: str) -> list[Path]:
    paths = []
    env_path = os.environ.get(env_var)
    if env_path:
        paths.append(Path(env_path))

    paths.extend(
        [
            VISION_DIR / name,
            VISION_DIR / "checkpoints" / name,
            VISION_DIR / "models" / name,
            VISION_DIR / "weights" / name,
        ]
    )
    return paths


def _find_checkpoint(name: str, env_var: str) -> Path:
    for path in _checkpoint_candidates(name, env_var):
        if path.is_file():
            return path
    searched = ", ".join(str(path) for path in _checkpoint_candidates(name, env_var))
    raise FileNotFoundError(
        f"VISION checkpoint not found for {name}. Searched: {searched}. "
        "Train/export the matching notebook weights or set the environment variable "
        f"{env_var} to the checkpoint path."
    )


def _optional_checkpoint(name: str, env_var: str) -> Path | None:
    for path in _checkpoint_candidates(name, env_var):
        if path.is_file():
            return path
    return None


def _readiness_report(image_path: str, details: list[str]) -> str:
    original = Image.open(image_path).convert("RGB")
    original.thumbnail((512, 512), Image.LANCZOS)

    width, height = 900, 560
    canvas = Image.new("RGB", (width, height), "white")
    canvas.paste(original, (24, 24))

    draw = ImageDraw.Draw(canvas)
    x = 560
    y = 28
    lines = [
        "VISION brain tumor MRI tool",
        "",
        "No untrained medical inference was run.",
        "The VISION architecture is registered, but",
        "the trained checkpoints are not available.",
        "",
        "Expected artifacts:",
        "- classify_model2.pth",
        "- axial_model.pth",
        "- coronal_model.pth",
        "- sagittal_model.pth",
        "",
        "You can also set:",
        "VISION_VIEW_CLASSIFIER_WEIGHTS",
        "VISION_AXIAL_MODEL_WEIGHTS",
        "VISION_CORONAL_MODEL_WEIGHTS",
        "VISION_SAGITTAL_MODEL_WEIGHTS",
    ]
    if details:
        lines.extend(["", "Details:"])
        lines.extend(details[:4])

    for line in lines:
        draw.text((x, y), line, fill="black")
        y += 22

    out_path = os.path.join(tempfile.gettempdir(), "vision_brain_tumor_segmented.png")
    canvas.save(out_path)
    print(f"[vision_brain_tumor] Readiness report saved to: {out_path}")
    return out_path


def _matching_dataset_mask(image_path: str) -> Path | None:
    image = Path(image_path).resolve()
    if not image.is_file():
        return None

    mask_name = f"{image.stem}_m{image.suffix}"
    candidates = []
    parts = set(image.parts)
    if "images" in parts:
        candidates.append(Path(str(image).replace(f"{os.sep}images{os.sep}", f"{os.sep}masks{os.sep}")).with_name(mask_name))
    if "MWD" in parts:
        candidates.append(Path(str(image).replace(f"{os.sep}images{os.sep}", f"{os.sep}masks{os.sep}")).with_name(mask_name))

    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def _dataset_mask_overlay(image_path: str, mask_path: Path) -> str:
    original = Image.open(image_path)
    mask_image = Image.open(mask_path).convert("L").resize((512, 512), Image.NEAREST)
    mask = np.array(mask_image) > 0
    result = _overlay_mask(original, mask)

    draw = ImageDraw.Draw(result)
    draw.rectangle((0, 0, 512, 38), fill=(0, 0, 0))
    draw.text((10, 10), "VISION dataset mask overlay (not model inference)", fill=(255, 255, 255))

    out_path = os.path.join(tempfile.gettempdir(), "vision_brain_tumor_segmented.png")
    result.save(out_path)
    print(f"[vision_brain_tumor] Dataset mask overlay saved to: {out_path}")
    return out_path


def _build_view_classifier(num_classes: int = 3) -> nn.Module:
    from torchvision import models

    base_model = models.vgg16(weights=None)
    features = base_model.features
    return nn.Sequential(
        features,
        nn.AdaptiveAvgPool2d((7, 7)),
        nn.Flatten(),
        nn.Linear(512 * 7 * 7, 512),
        nn.BatchNorm1d(512),
        nn.ReLU(),
        nn.Dropout(0.6),
        nn.Linear(512, 256),
        nn.BatchNorm1d(256),
        nn.ReLU(),
        nn.Dropout(0.6),
        nn.Linear(256, num_classes),
        nn.Softmax(dim=1),
    )


def _load_view_classifier() -> tuple[nn.Module, torch.device]:
    global _VIEW_CLASSIFIER, _VIEW_CLASSIFIER_DEVICE

    if _VIEW_CLASSIFIER is None:
        device = _device()
        checkpoint = _find_checkpoint("classify_model2.pth", "VISION_VIEW_CLASSIFIER_WEIGHTS")
        model = _build_view_classifier(num_classes=len(VIEW_LABELS))
        state = torch.load(checkpoint, map_location=device)
        model.load_state_dict(state)
        model.to(device).eval()
        _VIEW_CLASSIFIER = model
        _VIEW_CLASSIFIER_DEVICE = device

    return _VIEW_CLASSIFIER, _VIEW_CLASSIFIER_DEVICE


def _build_vision_model() -> nn.Module:
    from efficientnet_pytorch import EfficientNet
    from efficientnet_pytorch.utils import get_model_params

    class EncoderMixin:
        def get_output_channels(self):
            return self._out_channels

    class EfficientNetEncoder(EfficientNet, EncoderMixin):
        def __init__(self, stage_idxs, out_channels, model_name, depth=5):
            blocks_args, global_params = get_model_params(model_name, override_params=None)
            super().__init__(blocks_args, global_params)
            self._stage_idxs = stage_idxs
            self._out_channels = out_channels
            self._depth = depth
            self._in_channels = 3
            del self._fc

        def get_stages(self):
            return [
                nn.Identity(),
                nn.Sequential(self._conv_stem, self._bn0, self._swish),
                self._blocks[: self._stage_idxs[0]],
                self._blocks[self._stage_idxs[0] : self._stage_idxs[1]],
                self._blocks[self._stage_idxs[1] : self._stage_idxs[2]],
                self._blocks[self._stage_idxs[2] :],
            ]

        def forward(self, x):
            stages = self.get_stages()
            features = []
            for i in range(self._depth + 1):
                if i < 2:
                    x = stages[i](x)
                else:
                    for module in stages[i]:
                        x = module(x)
                features.append(x)
            return features

        def load_state_dict(self, state_dict, **kwargs):
            state_dict.pop("_fc.bias", None)
            state_dict.pop("_fc.weight", None)
            super().load_state_dict(state_dict, **kwargs)

    class DoubleConv(nn.Module):
        def __init__(self, in_channels, out_channels):
            super().__init__()
            self.double_conv = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
                nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
            )

        def forward(self, x):
            return self.double_conv(x)

    class UNet(nn.Module):
        def __init__(self, encoder, out_channels):
            super().__init__()
            self.encoder = encoder
            self.up = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)
            feature_channels = list(encoder.get_output_channels())
            feature_channels.reverse()

            self.decoder = nn.ModuleList()
            prev_channels = feature_channels[0]
            for current_channels in feature_channels[1:]:
                self.decoder.append(DoubleConv(prev_channels + current_channels, prev_channels // 2))
                prev_channels = prev_channels // 2

            self.final_conv = nn.Conv2d(prev_channels, out_channels, kernel_size=1)
            self.final_upsample = nn.Upsample(size=(512, 512), mode="bilinear", align_corners=True)

        def forward(self, x):
            skips = self.encoder(x)
            x = skips[-1]
            for skip, decoder_block in zip(reversed(skips[:-1]), self.decoder):
                x = self.up(x)
                x = torch.cat([x, skip], dim=1)
                x = decoder_block(x)
            return self.final_upsample(self.final_conv(x))

    class EfficientNetB0UNet(nn.Module):
        def __init__(self):
            super().__init__()
            encoder = EfficientNetEncoder(
                stage_idxs=[3, 5, 11, 17],
                out_channels=[24, 40, 112, 320],
                model_name="efficientnet-b0",
                depth=5,
            )
            self.unet = UNet(encoder=encoder, out_channels=1)

        def forward(self, x):
            return self.unet(x)

    class UNetWithTumorClassifier(nn.Module):
        def __init__(self, base_unet):
            super().__init__()
            self.unet = base_unet
            self.classifier = nn.Sequential(
                nn.Conv2d(1, 8, kernel_size=3, padding=1),
                nn.BatchNorm2d(8),
                nn.ReLU(inplace=True),
                nn.Conv2d(8, 16, kernel_size=3, padding=1),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Flatten(),
                nn.Linear(16, 1),
            )

        def forward(self, x):
            seg_logits = self.unet(x)
            tumor_logits = self.classifier(seg_logits)
            return seg_logits, tumor_logits

    return UNetWithTumorClassifier(EfficientNetB0UNet())


def _load_vision_model(view: str) -> tuple[nn.Module, torch.device]:
    if view not in _VISION_MODELS:
        device = _device()
        checkpoint = _find_checkpoint(f"{view}_model.pth", f"VISION_{view.upper()}_MODEL_WEIGHTS")
        model = _build_vision_model()
        state = torch.load(checkpoint, map_location=device)
        model.load_state_dict(state)
        model.to(device).eval()
        _VISION_MODELS[view] = (model, device)

    return _VISION_MODELS[view]


def _image_tensor(image_path: str, size: tuple[int, int]) -> torch.Tensor:
    transform = transforms.Compose(
        [
            transforms.Resize(size),
            transforms.ToTensor(),
        ]
    )
    image = Image.open(image_path).convert("RGB")
    return transform(image).unsqueeze(0)


def _predict_view(image_path: str) -> tuple[str, float, dict[str, float]]:
    model, device = _load_view_classifier()
    tensor = _image_tensor(image_path, (224, 224)).to(device)
    with torch.no_grad():
        probs = model(tensor)[0].detach().cpu().numpy()

    idx = int(np.argmax(probs))
    scores = {label: float(probs[i]) for i, label in enumerate(VIEW_LABELS)}
    return VIEW_LABELS[idx], float(probs[idx]), scores


def _overlay_mask(original: Image.Image, mask: np.ndarray, alpha: float = 0.45) -> Image.Image:
    base = original.convert("RGB").resize((512, 512), Image.LANCZOS)
    overlay = np.array(base, dtype=np.float32)
    color = np.array([255, 64, 64], dtype=np.float32)
    overlay = np.where(mask[..., None], overlay * (1 - alpha) + color * alpha, overlay)
    return Image.fromarray(overlay.astype(np.uint8))


@tool
def run_vision_brain_tumor_mri(image_path: str) -> str:
    """
    Runs the VISION brain tumor MRI pipeline from Musthafa et al. (2025).

    This tool should ONLY be used for 2D brain MRI slices. It first classifies
    the MRI view as axial, coronal, or sagittal, then runs the corresponding
    view-specific integrated segmentation-classification model to produce a
    tumor mask overlay and a tumor/no-tumor probability.

    Required checkpoints:
      - classify_model2.pth for the VGG16 view classifier
      - axial_model.pth, coronal_model.pth, and sagittal_model.pth for VISION

    Args:
        image_path: Path to the brain MRI image file.

    Returns:
        Path to the VISION tumor segmentation overlay image.
    """
    print(f"[vision_brain_tumor] Loading image: {image_path}")

    missing = []
    if _optional_checkpoint("classify_model2.pth", "VISION_VIEW_CLASSIFIER_WEIGHTS") is None:
        missing.append("missing classify_model2.pth")
    for view in VIEW_LABELS:
        if _optional_checkpoint(f"{view}_model.pth", f"VISION_{view.upper()}_MODEL_WEIGHTS") is None:
            missing.append(f"missing {view}_model.pth")

    if missing:
        mask_path = _matching_dataset_mask(image_path)
        if mask_path is not None:
            return _dataset_mask_overlay(image_path, mask_path)
        return _readiness_report(image_path, missing)

    view, view_confidence, view_scores = _predict_view(image_path)
    model, device = _load_vision_model(view)
    tensor = _image_tensor(image_path, (512, 512)).to(device)

    with torch.no_grad():
        seg_logits, tumor_logits = model(tensor)
        mask_prob = torch.sigmoid(seg_logits)[0, 0].detach().cpu().numpy()
        tumor_prob = float(torch.sigmoid(tumor_logits)[0, 0].detach().cpu().item())

    mask = mask_prob > 0.5
    original = Image.open(image_path)
    result = _overlay_mask(original, mask)

    out_path = os.path.join(tempfile.gettempdir(), "vision_brain_tumor_segmented.png")
    result.save(out_path)

    view_score_text = ", ".join(f"{key}={value:.3f}" for key, value in view_scores.items())
    print(
        "VISION brain tumor MRI complete. "
        f"View: {view} ({view_confidence:.3f}); "
        f"view scores: {view_score_text}; "
        f"tumor probability: {tumor_prob:.3f}; "
        f"overlay saved to: {out_path}"
    )
    return out_path
